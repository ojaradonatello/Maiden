-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobile_number` varchar(12) NOT NULL,
   `type` varchar(255) NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `staff_name`, `username`, `password`, `mobile_number`,`type`) VALUES
(1, 'Test Staff', 'test', 'test', '9826285858', 'admin'),
(11, 'The Viewer', 'viewer', 'viewer', '8585457545','viewer');

--
-- Indexes for dumped tables

--

-- Table structure for table `reg_maid`
--

CREATE TABLE `reg_maid` (
  `id` int(11) NOT NULL,
  `fist_name` varchar(255) NOT NULL,
  `second_name` varchar(255) NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `reg_maid` (`id`, `first name`, 'second_name','phone') VALUES

(1, 'Nasozi mary','07400000000');


-- Table structure for table `reg_maid`
--

CREATE TABLE `add_maid` (
  `id` int(11) NOT NULL,
  `fist_name` varchar(255) NOT NULL,
  `second_name` varchar(255) NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `add_maid` (`id`, `first_name`,'second_name','phone') VALUES

(1, 'Nasozi mary','07400000000');


CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `duration` varchar(12) NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `name`, `email`, `category`, `duration`) VALUES
(1, 'sharon', 'sha@gmail.com', 'Laundry', '1 week');

--
-- Indexes for dumped tables

