<?php
session_start();
include_once("helpers/db.php");
if(!isset($_SESSION['username'])){
        header("Location: login.php");
     }
$page_title = "View all staff";
include("inc/header.php");

?>


<link rel="stylesheet" href="assets/css/custom.css">

</head>
<body class="text-center">
<?php include("inc/menu.php"); ?>
<div class="container">
 <br><br>
    <table class="table">
        <tr>
            <th>First Name</th>
            <th>Second Name</th>
            <th>Phone</th>
            
        </tr>
        <?php
        $query = "SELECT * FROM add_maid";
        $query_run=mysqli_query($con,$query);
        while($data = mysqli_fetch_array($query_run)){
            
            ?>
            <tr>
                <td><?php echo $data['first_name']?></td>
                <td><?php echo $type['second_name'] ?></td>
                <td><?php echo $data['phone'] ?></td>
               
            </tr>
            <?php
        }
        ?>
    </table>
</div>
<?php
include_once("inc/bootstrap.php");
include_once("inc/footer.php");
?>