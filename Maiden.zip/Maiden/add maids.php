<?php

/* 
*/


$page_title = "Add maid";
include("inc/header.php");
session_start();
include_once("helpers/db.php");
if(!isset($_SESSION['username'])){
        header("Location: login.php");
     }

if(isset($_POST['submit'])){
    $number = $_POST['first_name'];
    $type = $_POST['second_name'];
    $rent = $_POST['phone'];
    
    $query = "INSERT INTO `reg_maid` (`first_name`, `second_name`, `phone`) VALUES ('$first_name', '$second_name', '$phone')";
    
    if(mysqli_query($con,$query)){
        $msg="Added successfully!";
    }else{
        $msg="Some error occured!";
    }
}

?>

<link rel="stylesheet" href="assets/css/custom.css">

</head>
<body>
<div class="row">
<div class="col-md-12">
<?php include("inc/menu.php"); ?>
</div></div>
<div class="row">
<form class="form-signin text-center" method="post">
<!--      <img class="mb-4" src="../../assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">-->
      <h1 class="h3 mb-3 font-weight-normal"><?php echo $page_title;?></h1>
      <?php
            if(isset($msg)){
               echo "<div class='alert alert-warning' role='alert'>".$msg."</div>";
            }
      ?>
             <label for="rent">first name</label>
              <input type="text" name="rent" id="rent" class="form-control" required>
             <br>

              <label for="rent">second name</label>
              <input type="text" name="rent" id="rent" class="form-control" required>
             <br>

              <label for="number">Phone.</label>
              <input type="text" name="number" id="number" class="form-control" required autofocus>
        
      

              <input type="submit" class="btn btn-primary" name="submit">
      </div>
          </form>
          </div>
<?php
include_once("inc/bootstrap.php");
include_once("inc/footer.php");
?>