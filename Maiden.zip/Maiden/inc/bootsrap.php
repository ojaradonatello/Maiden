
   <script src="/dbms/assets/js/jquery.js"></script>
   <script src="/dbms/assets/js/bootstrap.min.js"></script>
   <script src="/dbms/assets/js/popper.js"></script>